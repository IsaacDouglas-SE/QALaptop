echo $1 >> animals.txt
exit 0